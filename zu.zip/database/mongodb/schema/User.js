const mongodb = require("mongoose");
const Date = require('../../../function/DapiCode/date')

const Schema = new mongodb.Schema(
    {
      nomor: String,
      saldo: { type: Number, default: 0 },
      Date_Create: { type: String, default: Date },
      Total_Order: { type: Number, default: 0 },
    },
    {
      collection: "User",
    }
);
  
const User = mongodb.model("User", Schema);

module.exports = User