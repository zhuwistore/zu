const mongodb = require("mongoose");

const Schema = new mongodb.Schema(
    {
      name: String,
      code: String,
      deksripsi: String,
      keteranganBeli: String,
      price: Number,
    },
    {
      collection: "Product",
    }
);
  
const Product = mongodb.model("Product", Schema);

module.exports = Product