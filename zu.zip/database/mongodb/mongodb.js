const mongoose = require('mongoose');
const db = mongoose.connection;

async function connectDB() {
    try {
        await mongoose.connect("mongodb+srv://zhulstoremandiri:igq6iqnjTXPwkVIq@zhuldata.c4zk8em.mongodb.net/?retryWrites=true&w=majority", {
            dbName: "ZhulData"
        });
    } catch (error) {
        console.error("MongoDB connection error:", error);
    }
}

db.on("disconnected", () => {
    console.log("MongoDB connection closed ❌");
});

db.on("connected", () => {
    console.log("DATABASE SUDAH SIAP✅");
});

module.exports = connectDB;