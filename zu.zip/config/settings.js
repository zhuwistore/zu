const fs = require('fs')
const chalk = require('chalk')
// EDIT DISINI
global.owner = ['6285336393488','6282117836284'] // no own
global.ownerName = 'Store Bot'
global.kontakOwner = "6285336393488"
global.packname = 'Sticker By'
global.author = 'Store Bot'
global.sessionName = 'session' // nama session
global.delayy = 3000
global.domain = 'https://zhstore.my.id' // Isi Domain Lu
global.apikey = 'ptla_4MJW8pZ9QIGx0cyl2Lv3UKFezfC9xN1iWHRkW6afhNj' // Isi Apikey Plta Lu
global.capikey = 'ptlc_CJopH999L6yI0mqLfJmkF11iU4V4vMDe2Q3ovrQxURl' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.thumbnail = fs.readFileSync('./thumb.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})