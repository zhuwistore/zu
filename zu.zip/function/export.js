module.exports = {
    daftarAkun: require('./DapiCode/registerAkun'),
    tambahSaldo: require('./DapiCode/tambahsaldo'),
    kurangSaldo: require('./DapiCode/kurangsaldo'),
    listProduk: require('./DapiCode/listProduk'),
    tambahStock: require('./DapiCode/tambahstock'),
    kurangStock: require('./DapiCode/kurangstock'),
    infoAkun: require('./DapiCode/infoAkun'),
    orderBarang: require('./DapiCode/orderBarang')
}