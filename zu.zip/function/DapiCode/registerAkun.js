const User = require("../../database/mongodb/schema/User");

async function registerAkun(number) {
  try {
    const cekUser = await User.findOne({ nomor: number });

    if (cekUser) {
      return "*Kamu sudah mempunyai akun sebelumnya!!*";
    } else if (number == "") {
      return "*Sepertinya ada masalah saat pendaftaran di bagian nomor, Harap hubungi owner agar dapat di perbaiki!!*";
    }

    const newUser = new User({
      nomor: number
    });

    await newUser.save();

    return "*Selamat nomor kamu sudah terdaftar di database kami!!*";
  } catch (error) {
    console.error(error);
    return "*Sesuatu error harap hubungi owner agar dapat di perbaiki!!*";
  }
}

module.exports = registerAkun;