const User = require("../../database/mongodb/schema/User");

async function addBalance(number, jumlah) {
  let message = "";
  try {
    const Akun = await User.findOne({ nomor: number });
    const regex = /^[0-9]+$/;

    
    if (number == "") {
      return "*Harap reply orang yang ingin di tambahkan saldo nya!!*";
    } else if (!Akun) {
      return `*Nampak nya user ini belum mempunyai akun harap daftar terlebih dahulu!!*`;
    } else if (!regex.test(jumlah)) {
      return "*Masukkan jumlah saldo dengan angka saja!!*";
    } else if (jumlah == "") {
      return "*Masukkan jumlah saldo yag di ingin kan dan tidak boleh kosong!!*";
    }

    await User.updateOne({ nomor: number }, { $inc: { saldo: jumlah } });

    const Akun2 = await User.findOne({ nomor: number });

    return `*─────〔 UPDATE SALDO 〕─────*\n\n○ Nomor : *${number}*\n○ Saldo Terakhir : *Rp. ${Akun.saldo.toLocaleString('id-ID')}*\n○ Saldo Sekarang : *Rp. ${Akun2.saldo.toLocaleString('id-ID')}*\n\n_*Jika ada kendala harap hubungi owner!!*_`;
  } catch (error) {
    console.error(error);
    message = "*Sesuatu error, harap hubungi owner agar dapat diperbaiki!!*";
    return message;
  }
}

module.exports = addBalance;

async function addBalance(number, jumlah) {
  let message = "";
  try {
    const Akun = await User.findOne({ nomor: number });
    const regex = /^[0-9]+$/;

    
    if (number == "") {
      return "*Harap reply orang yang ingin di tambahkan saldo nya!!*";
    } else if (!Akun) {
      return `*Nampak nya user ini belum mempunyai akun harap daftar terlebih dahulu!!*`;
    } else if (!regex.test(jumlah)) {
      return "*Masukkan jumlah saldo dengan angka saja!!*";
    } else if (jumlah == "") {
      return "*Masukkan jumlah saldo yag di ingin kan dan tidak boleh kosong!!*";
    }

    await User.updateOne({ nomor: number }, { $inc: { saldo: jumlah } });

    const Akun2 = await User.findOne({ nomor: number });

    return `*─────〔 UPDATE SALDO 〕─────*\n\n○ Nomor : *${number}*\n○ Saldo Terakhir : *Rp. ${Akun.saldo.toLocaleString('id-ID')}*\n○ Saldo Sekarang : *Rp. ${Akun2.saldo.toLocaleString('id-ID')}*\n\n_*Jika ada kendala harap hubungi owner!!*_`;
  } catch (error) {
    console.error(error);
    message = "*Sesuatu error, harap hubungi owner agar dapat diperbaiki!!*";
    return message;
  }
}

module.exports = addBalance;