const Stock = require("../../database/mongodb/schema/Stock");

async function deleteStock(data) {
  try {
    if (data == "") {
      return "*Bot tidak mendeteksi data nya, harap reply list stock yang ingin di hapus!!*";
    }

    await data.split("\n").forEach(async (product) => {
      const Datas = await Stock.findOne({ data: product });

      if (!Datas) {
        return;
      }

        await Stock.deleteOne({ data: product })
    });

    return "*Berhasail menghapus stock dengan sesuai data yang ada di list stock*";
  } catch (error) {
    console.error(error);
    return "*Sesuatu error, harap hubungi owner agar dapat diperbaiki!!*";
  }
}

module.exports = deleteStock;