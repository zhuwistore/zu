const User = require("../../database/mongodb/schema/User");

async function cekInfoUser(number) {
  try {
    const cekUser = await User.findOne({ nomor: number });

    if (!cekUser) {
      return "*Harap mendaftar terlebih dahulu jika ingin menggunakan command ini. Ketik daftar untuk mendaftar!!*";
    }

    return `*─────〔 PROFILE 〕─────*\n\n○ Nomor : *${cekUser.nomor.toLocaleString('id-ID')}* \n○ Saldo : *Rp ${cekUser.saldo.toLocaleString('id-ID')}*\n○ Time Create : *${cekUser.Date_Create}*\n○ Total Order : *${cekUser.Total_Order}* \n\n𝘐𝘯𝘨𝘪𝘯 𝘥𝘦𝘱𝘰𝘴𝘪𝘵 𝘴𝘪𝘭𝘢𝘩𝘬𝘢𝘯 𝘬𝘦𝘵𝘪𝘬 𝘤𝘰𝘮𝘮𝘢𝘯𝘥 *.𝘥𝘦𝘱𝘰𝘴𝘪𝘵*`;
  } catch (error) {
    console.error(error);
    message = "*Sesuatu error, harap hubungi owner agar dapat diperbaiki!!*";
    return message;
  }
}

module.exports = cekInfoUser;