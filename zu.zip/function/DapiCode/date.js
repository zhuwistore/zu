const date = new Date();
const Tanggal = date.getDate();
const Bulan = date.getMonth() + 1;
const Tahun = date.getFullYear();
const Hari = date.getDay(); // Mendapatkan angka hari
const namaHari = [
  "Minggu",
  "Senin",
  "Selasa",
  "Rabu",
  "Kamis",
  "Jumat",
  "Sabtu",
][Hari];
const namaBulan = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember"
][Bulan - 1];
const Time = `${namaHari},${Tanggal} ${namaBulan} ${Tahun}`;

module.exports = Time