const User = require("../../database/mongodb/schema/User");

async function deleteBalance(number, jumlah) {
  try {
    const Akun = await User.findOne({ nomor: number });
    const regex = /^[0-9]+$/;

    if (number == "") {
      return "*Harap reply orang yang ingin di di kurangkan saldo nya!!*";
    } else if (!Akun) {
      return "*Nampak nya user ini belum mempunyai akun harap .daftar terlebih dahulu!!*";
    } else if (!regex.test(jumlah)) {
      return "*Masukkan jumlah saldo dengan angka saja!!*";
    } else if (jumlah == "") {
      return "*Masukkan jumlah saldo yang ingin di kurangkan dan tidak boleh kosong!!*";
    }

    await User.updateOne(
      { nomor: number },
      { $inc: { saldo: -jumlah } }
    );

    const Akun2 = await User.findOne({ nomor: number });

    return `*─────〔 KURANG SALDO 〕─────*\n\n○ Nomor : *${number}*\n○ Saldo Terakhir : *Rp. ${Akun.saldo.toLocaleString('id-ID')}*\n○ Saldo Sekarang : *Rp. ${Akun2.saldo.toLocaleString('id-ID')}*\n\n_*Jika ada kendala harap hubungi owner!!*_`;
  } catch (error) {
    console.error(error);
    return "*Sesuatu error, harap hubungi owner agar dapat diperbaiki!!*";
  }
}

module.exports = deleteBalance;