const Product = require("../../database/mongodb/schema/Product");
const Stock = require('../../database/mongodb/schema/Stock')

async function cekStock() {
  let message = ""
  try {
    const allData = await Product.find();

    const stockBarang = async (code) => {
      const hasil = await Stock.aggregate([
          {
            $match: {
              code: code
            }
          },
          {
            $group: {
              _id: '$code',
              count: { $sum: 1 }
            }
          }
        ]).exec();

        const countValue = hasil.length > 0 ? hasil[0].count : 0;
        return countValue
  }

    message += "*LIST PRODUK :*\nContoh Order Ketik: *.order ytnogar 1*\n\n";
    
    for (const product of allData) {
      message += `*Code :* ${product.code}\n`;
      message += `*Name :* ${product.name}\n`;
      message += `*Deskripsi :* ${product.deksripsi}\n`;
      message += `*Harga :* Rp ${product.price.toLocaleString('id-ID')}\n`;
      message += `*Stock :* ${await stockBarang(product.code)}\n`;
      message += "------------------------\n";
    }

    return message;
  } catch (error) {
    console.error(error);
    message = "*Sesuatu error harap hubungi owner agar dapat di perbaiki!!*";
    return message;
  }
}

module.exports = cekStock;