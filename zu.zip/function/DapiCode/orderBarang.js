const Product = require('../../database/mongodb/schema/Product')
const Stock = require('../../database/mongodb/schema/Stock')
const User = require('../../database/mongodb/schema/User')
const Dates = require('./date')

async function orderBarang(nomor_pembeli,code,jumlah,socket,from,quoteds) {
  try {
    const CekPembeli = await User.findOne({ nomor: nomor_pembeli });
    const allStock = await Stock.find({ code: code });
    const cekProduk = await Product.findOne({ code: code });

    const regexInt = /^[0-9]+$/;

    const stockBarang = async (code) => {
      const hasil = await Stock.aggregate([
        {
          $match: {
            code: code,
          },
        },
        {
          $group: {
            _id: "$code",
            count: { $sum: 1 },
          },
        },
      ]).exec();

      const countValue = hasil.length > 0 ? hasil[0].count : 0;
      return countValue;
    };

    if (!CekPembeli) {
      await socket.sendMessage(
        from,
        { text: "*Harap mendaftar terlebih dahulu🙏, dengan ketik daftar*" },
        { quoted: quoteds }
      );
      return;
    } else if (!cekProduk) {
      await socket.sendMessage(
        from,
        { text: "*Harap masukkan kode dengan benar!!*" },
        { quoted: quoteds }
      );
      return;
    } else if (CekPembeli.saldo < cekProduk.price * jumlah) {
      await socket.sendMessage(
        from,
        { text: "*Mohon maaf saldo kamu tidak mencukupi🙏*" },
        { quoted: quoteds }
      );
      return;
    } else if (jumlah == 0 || !regexInt.test(jumlah)) {
      await socket.sendMessage(
        from,
        { text: "*Harap masukkan input jumlah beli dengan benar!!*" },
        { quoted: quoteds }
      );
      return;
    } else if (await stockBarang(code) < jumlah) {
      await socket.sendMessage(
        from,
        { text: "*Mohon maaf stock barang tidak mencukupi🙏*" },
        { quoted: quoteds }
      );
      return;
    } else if (await stockBarang(code) == 0) {
      await socket.sendMessage(
        from,
        { text: "*Mohon maaf stock yang kamu beli telah HABIS/SOLD OUT🙏*" },
        { quoted: quoteds }
      );
      return;
    } 

    let message = `*TERIMA KASIH SUDAH MEMBELI ${cekProduk.name.toLocaleUpperCase()} DI ZHUWI STORE*\n\n`;

    const date = new Date();
    const Tanggal = date.getDate();
    
    // Menambahkan 4 bulan ke tanggal saat ini
    const nextFourMonths = new Date(date);
    nextFourMonths.setMonth(date.getMonth() + 4);
    
    const Bulan = nextFourMonths.getMonth() + 1;
    const Tahun = nextFourMonths.getFullYear();
    const Hari = nextFourMonths.getDay(); // Mendapatkan angka hari
    const namaHari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"][Hari];
    const namaBulan = [
      "Januari", "Februari", "Maret", "April", "Mei", "Juni",
      "Juli", "Agustus", "September", "Oktober", "November", "Desember"
    ][Bulan - 1];
    const Time = `${namaHari},${Tanggal} ${namaBulan} ${Tahun}`;
    
    if (code == "YTNOGAR" || code == "YTFULLGAR" || code == "ytnogar" || code == "ytfullgar") {
      message += `*EXPIRED TIME : ${Time}*\n`
    }

    message += "_*Dibawah ini adalah akun yang anda beli👇*_\n"
    let total = 0

    for (const barang of allStock) {
      total++

      if (total > jumlah) {
        break
      }

      message += `╔══《 *${total}* 》\n`
      message += `${barang.data.replace('\n', /\n/g)}\n`
      message += "\n"

      await Stock.deleteOne({ data: barang.data })
    }
      
    message += `\n${cekProduk.keteranganBeli}`

    await User.updateOne(
      { nomor: nomor_pembeli },
      { $inc: { saldo: -cekProduk.price * jumlah, Total_Order: jumlah } }
    )

    await socket.sendMessage(`${CekPembeli.nomor}@s.whatsapp.net`, { text: message })

    await socket.sendMessage(from, { text: `─────〔 *TRANSAKSI SUKSES* 〕─────\n\n*» Item :* ${cekProduk.name}\n*» Jumlah :* ${jumlah}\n*» Harga :* ${cekProduk.price * jumlah}\n*» Waktu :* ${Dates}\n*» Note :* Silahkah Cek pesan dari Bot\n\n─────〔 *TERIMA KASIH* 〕─────` }, { quoted: quoteds })

  } catch (error) {
    console.log(error)
    await socket.sendMessage(from, { text: "Sesuatu error, Harap hubungi owner!!" }, { quoted: quoteds })
  }
}

module.exports = orderBarang