const Stock = require("../../database/mongodb/schema/Stock");
const Product = require("../../database/mongodb/schema/Product");

async function addStock(code, data) {
  try {
    const cekCode = await Product.findOne({ code: code });

    if (!cekCode) {
      return "*Gagal menambahkan stock, Harap masukkan kode dengan benar*";
    } else if (data == "") {
      return "*Bot tidak mendeteksi data nya, harap reply list stock nya!!*";
    }

    await data.split("\n").forEach(async (product) => {
      const addStock = new Stock({
        code: code,
        data: product,
      });

        await addStock.save()
    });

    return `*Berhasil menambahkan stock dengan kode ${code} ke database!!*`;
  } catch (error) {
    console.error(error);
    return "*Sesuatu error harap hubungi owner agar dapat di perbaiki!!*";
  }
}

module.exports = addStock;