<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/tiff</h1>
  <p>Default Jimp tiff encoder/decoder.</p>
</div>
