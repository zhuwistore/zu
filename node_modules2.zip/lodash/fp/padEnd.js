var convert = require('./convert'),
    func = convert('padEnd', require('../padEnd'));

func.placeholder = require('./placeholder');
module.exports = func;
