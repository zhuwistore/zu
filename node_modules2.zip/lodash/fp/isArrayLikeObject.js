var convert = require('./convert'),
    func = convert('isArrayLikeObject', require('../isArrayLikeObject'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
