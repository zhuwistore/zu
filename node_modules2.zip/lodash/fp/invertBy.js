var convert = require('./convert'),
    func = convert('invertBy', require('../invertBy'));

func.placeholder = require('./placeholder');
module.exports = func;
